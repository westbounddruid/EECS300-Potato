Code Repo for the EECS330 Spring 2018 group, Potato
